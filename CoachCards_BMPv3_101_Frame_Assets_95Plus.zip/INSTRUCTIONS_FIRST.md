# CoachCards BMP v3 — Dumbbell Assets & Integration Rules

## Source assets: use these files, do NOT redraw, synthesize or substitute
This archive contains the ORIGINAL 101 consistent transparent WebP production frames, exactly named `bmp-000.webp` through `bmp-100.webp`. Each has 1000 × 410 pixels and RGBA transparency. `bmp-100.webp` is the existing full-illumination + green-underglow frame. The visual preview is `bmp_progression_preview.png` (a contact sheet, NOT an asset to render).

## Installation
Unzip the `bmp-frames/` folder INTO the Astro project `public/assets/` directory, giving exactly these URLs:
- `public/assets/bmp-frames/bmp-000.webp` -> `/assets/bmp-frames/bmp-000.webp`
- ...
- `public/assets/bmp-frames/bmp-100.webp` -> `/assets/bmp-frames/bmp-100.webp`
No extra parent nesting. Do not commit ZIP or preview to public unless expressly desired. Do not regenerate files with Claude or an image model. Keep one dumbbell image element, and change its source; do not preload 101 images.

## Mapping rule — UPDATED for BMP v3
The trainer BMP numerical score comes from the existing secure production RPC `get_own_trainer_profile()` (`bmp_score`); do not recalculate BMP, substitute a tier score, or change Trending/Fresh Face.

- No reviews or absent/invalid score: preserve existing zero-review / loading / unavailable display as appropriate. Do not fabricate a score.
- Finite BMP < 95.0: use the nearest whole-number frame, clamped to `bmp-000` ... `bmp-094`; crucially, 94.9 must still be `bmp-094` (NOT `bmp-095` or `bmp-100`).
- Finite BMP >= 95.0: ALWAYS use `bmp-100.webp` — full neon handle + fully lit rings + maximum underglow. The source `bmp-095.webp` through `bmp-099.webp` remain in the complete pack but are deliberately not used by this latest mapping.
- BMP numerical readout remains the actual server score to one decimal place: 95.0 displays 95.0, 97.3 displays 97.3, NOT 100.0.
- Tier thresholds stay as defined in `src/lib/bmpConfig.ts`.

Suggested implementation (adapt to existing Astro/TypeScript code):

```ts
function getBmpDumbbellSrc(rawScore: number | null | undefined): string | null {
  if (rawScore == null || !Number.isFinite(rawScore)) return null;
  const score = Math.max(0, Math.min(100, rawScore));
  const frame = score >= 95 ? 100 : Math.min(94, Math.round(score));
  return `/assets/bmp-frames/bmp-${String(frame).padStart(3, '0')}.webp`;
}
```

Example boundary checks:
- 0.0 -> bmp-000.webp (only when a score should actually render)
- 71.1 -> bmp-071.webp
- 71.5 -> bmp-072.webp
- 76.7 -> bmp-077.webp
- 81.4 -> bmp-081.webp
- 94.4 -> bmp-094.webp
- 94.9 -> bmp-094.webp
- 95.0 -> bmp-100.webp
- 97.3 -> bmp-100.webp
- 99.9 -> bmp-100.webp
- 100.0 -> bmp-100.webp

## Required Claude Code workflow
1. INVESTIGATE: inspect `src/pages/dashboard.astro` (`renderMyBmp()`), `src/lib/bmpDumbbell.ts`, existing SVG/asset use, and the secure BMP score pipeline. Identify current image renderer and preserve layout.
2. INSTALL files: confirm all 101 WebP files actually exist after copying, parse correctly, have RGBA transparency and consistent dimensions. Do not claim installation based only on this manifest.
3. MINIMAL FIX: wire the My BMP dumbbell image to `getBmpDumbbellSrc` using the actual score; retain current loading/no-review behaviour, numeric accuracy, aspect ratio, accessibility and responsiveness. Do not change formula/database/tiers.
4. VERIFY: test every integer frame and listed boundary values; check that only the necessary image is fetched and CSS is not forcing a blank background or cropping the glow. Run production Astro build.
5. REPORT: files changed, verified asset count, boundary test output, build result, unresolved items. Do not commit/push/deploy until user asks.

## Verification note
File integrity, dimensions, RGBA and continuity were checked when producing this ZIP. **This does not prove the assets are already installed in Claude's repository.** Claude must extract the archive and verify the actual project contents before reporting success.
